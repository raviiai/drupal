<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yu', 'cui', 'ya', 'zhu', 'cu', 'dan', 'shen', 'zhong', 'chi', 'yu', 'hou', 'feng', 'la', 'yang', 'chen', 'tu',
  0x10 => 'yu', 'guo', 'wen', 'huan', 'ku', 'jia', 'yin', 'yi', 'lou', 'sao', 'jue', 'chi', 'xi', 'guan', 'yi', 'wen',
  0x20 => 'ji', 'chuang', 'ban', 'hui', 'liu', 'chai', 'shou', 'nue', 'dian', 'da', 'bie', 'tan', 'zhang', 'biao', 'shen', 'cu',
  0x30 => 'luo', 'yi', 'zong', 'chou', 'zhang', 'zhai', 'sou', 'se', 'que', 'diao', 'lou', 'lou', 'mo', 'qin', 'yin', 'ying',
  0x40 => 'huang', 'fu', 'liao', 'long', 'qiao', 'liu', 'lao', 'xian', 'fei', 'dan', 'yin', 'he', 'ai', 'ban', 'xian', 'guan',
  0x50 => 'gui', 'nong', 'yu', 'wei', 'yi', 'yong', 'pi', 'lei', 'li', 'shu', 'dan', 'lin', 'dian', 'lin', 'lai', 'bie',
  0x60 => 'ji', 'chi', 'yang', 'xuan', 'jie', 'zheng', 'me', 'li', 'huo', 'lai', 'ji', 'dian', 'xuan', 'ying', 'yin', 'qu',
  0x70 => 'yong', 'tan', 'dian', 'luo', 'luan', 'luan', 'bo', 'bo', 'gui', 'ba', 'fa', 'deng', 'fa', 'bai', 'bai', 'qie',
  0x80 => 'ji', 'zao', 'zao', 'mao', 'de', 'pa', 'jie', 'huang', 'gui', 'ci', 'ling', 'gao', 'mo', 'ji', 'jiao', 'peng',
  0x90 => 'gao', 'ai', 'e', 'hao', 'han', 'bi', 'wan', 'chou', 'qian', 'xi', 'ai', 'xiao', 'hao', 'huang', 'hao', 'ze',
  0xA0 => 'cui', 'hao', 'xiao', 'ye', 'po', 'hao', 'jiao', 'ai', 'xing', 'huang', 'li', 'piao', 'he', 'jiao', 'pi', 'gan',
  0xB0 => 'pao', 'zhou', 'jun', 'qiu', 'cun', 'que', 'zha', 'gu', 'jun', 'jun', 'zhou', 'zha', 'gu', 'zhao', 'du', 'min',
  0xC0 => 'qi', 'ying', 'yu', 'bei', 'zhao', 'zhong', 'pen', 'he', 'ying', 'he', 'yi', 'bo', 'wan', 'he', 'ang', 'zhan',
  0xD0 => 'yan', 'jian', 'he', 'yu', 'kui', 'fan', 'gai', 'dao', 'pan', 'fu', 'qiu', 'sheng', 'dao', 'lu', 'zhan', 'meng',
  0xE0 => 'li', 'jin', 'xu', 'jian', 'pan', 'guan', 'an', 'lu', 'xu', 'zhou', 'dang', 'an', 'gu', 'li', 'mu', 'ding',
  0xF0 => 'gan', 'xu', 'mang', 'wang', 'zhi', 'qi', 'yuan', 'tian', 'xiang', 'dun', 'xin', 'xi', 'pan', 'feng', 'dun', 'min',
];
